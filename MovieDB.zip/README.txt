Files:
fresh_tomatoes.py: provided which contains code to render data into HTML file and open in browser
media.py: contains class definitions for movie
entertainment_center.py: contains my favorite movie data

Instructions:
Edit entertainment_center.py file to contain your favorite movies

Format:
<<movie_instance>> = media.Movie(<<Movie title string>>, 
				<<Movie description string>>, 
				<<URL string for movie box art image>>,
				<<URL string for trailer on youtube>>,
				<<String for year released>>, #no current functionality
				<<String for MPAA movie rating>>) #no current functionality

Extract all files to the same folder and run entertainment_center.py module